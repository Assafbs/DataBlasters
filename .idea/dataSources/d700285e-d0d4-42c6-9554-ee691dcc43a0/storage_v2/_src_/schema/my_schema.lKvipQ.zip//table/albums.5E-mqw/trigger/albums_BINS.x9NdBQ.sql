CREATE TRIGGER albums_BINS
  BEFORE INSERT
  ON albums
  FOR EACH ROW
  BEGIN    
    IF (NEW.release_month < 1 OR NEW.release_month > 12)
			THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'invalid release_month';
    END IF;
END;

