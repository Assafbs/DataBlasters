CREATE TRIGGER albums_BUPD
  BEFORE UPDATE
  ON albums
  FOR EACH ROW
  BEGIN    
    IF (NEW.release_month < 1 OR NEW.release_month > 12)
			THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'invalid release_month';
    END IF;
END;

